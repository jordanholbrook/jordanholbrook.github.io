Dias, Daniel A., and Joao B. Duarte, "Monetary Policy, Housing Rents,
and Inflation Dynamics", Journal of Applied Econometrics, forthcoming.

All files are zipped in dd-files.zip.

In order to replicate all figures at once, use the run_all.m file.
The Matlab econometrics toolbox is needed.

Each figure can also be replicated individually by running the
Replica_FigureX.m files, replacing X with the desired figure.

The main datasets used for the proxy SVARs are saved in datasets/data
under Replication_files.

The IRFs associated with the FAVAR and R&R are saved under datasets/IRF
under Replication_files.

To run the FAVAR IRFs, all the documentation is inside the FAVAR
folder. The dataset is the FRED-MD database (McCracken and Ng (2016).
These are the steps to replicate the FAVAR IRFS:

1- Transform the data by using the data_transform.m file

2- Estimate and identify the FAVAR using FAVAR_fred_cpitest.rpf. (Rats
(ESTIMA) is needed in order to run his file)

To run the R&R IRFs, all the documentation is inside the R&R folder.
The dataset is PPdata1.xlsx. To replicate the R&R IRFS one just needs
to run RR_irfs.rpf. (Rats (ESTIMA) is needed in order to run his file)

Daniel A. Dias
Senior Economist, Global Financial Institutions
International Finance Division
Board of Governors of the Federal Reserve System
daniel.dias [AT] frb.gov