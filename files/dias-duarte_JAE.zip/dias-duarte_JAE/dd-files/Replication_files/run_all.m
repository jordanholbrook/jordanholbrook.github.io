% This file replicates all Figures in `` Monetary Policy, Housing Rents,
% and Inflation Dynamics
% by Daniel Dias and Joao B. Duarte, 2018

clear all; 
close all;

Replicate_Figure1
Replicate_Figure2
Replicate_Figure3
Replicate_Figure4_5
Replicate_Figure6
Replicate_Figure7
Replicate_Figure8