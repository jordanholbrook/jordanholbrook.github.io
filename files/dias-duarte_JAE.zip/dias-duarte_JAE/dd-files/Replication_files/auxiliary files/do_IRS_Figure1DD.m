display1= cell2mat(values(VAR.MAP,plotdisplay));

f=figure; 
for nvar = 1:length(display1)
                  
                
        if isempty(VARci)==0
            
        subplot(3,2,nvar)
        h=plot(0:VAR.irhor-1,VARci.irs(:,display1(nvar),shock), 'r');
        set(h(1),'linewidth',1.5);
        if nvar == 2
        ylim([-0.2 0.6]);
        set(gca,'YTick',-0.2:0.2:0.6);
        end
        xlim([0 VAR.irhor-1])
        

            
                if isempty(VARci.irsH4)==0
                [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4(:,display1(nvar))',VARci.irsL4(:,display1(nvar))',[0 0 1],[0 0 0],1,0.15);
                end
            end
            hline(0,'k-')
            ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            %xl=xlabel(xlab_text);
            %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
            %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
            
            if nvar == 1
            end

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
            %str=strcat('figures/',name,'_',plotdisplay{nvar});
            %saveas(gcf,str,'epsc');


end

%matlab2tikz('irfs_hfi_rents_figure.tikz');

            
            