
f=figure;                 
               
            
            
        subplot(1,2,1)
        h=plot(0:VAR.irhor-1,VAR.irs_cpi(:,4,shock), 'r', 0:VAR.irhor-1,VAR.irs_cpi(:,5,shock), 'b--');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4(:,4)',VARci.irsL4(:,4)',[0 0 1],[0 0 0],1,0.1)
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4(:,5)',VARci.irsL4(:,5)',[0 0 1],[0 0 0],1,0.25)
        set(h(1),'linewidth',1.5);
        set(h(2),'linewidth',1.5);
        %ylim([-0.4 0.2]);
        ti = title('CPI vs. CPI Net of Medical Care');
        legend('CPI','CPI net of Medical', 'location','south')
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
            hline(0,'k-')
            %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            %xl=xlabel(xlab_text);
            %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
            %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
         subplot(1,2,2)   
        h=plot(0:VAR.irhor-1,VARci.irsDIFF, 'r');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsHDIFF',VARci.irsLDIFF',[0 0 1],[0 0 0],1,0.15)
        set(h(1),'linewidth',1.5);
        %ylim([-0.1 0.2]);
        ti = title('Difference: CPI vs. CPI Net of Medical Care');
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
        hline(0,'k-')
        %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
        %xl=xlabel(xlab_text);
        %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
        %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
            



%matlab2tikz('irfs_test_figure2.tikz');

            
            