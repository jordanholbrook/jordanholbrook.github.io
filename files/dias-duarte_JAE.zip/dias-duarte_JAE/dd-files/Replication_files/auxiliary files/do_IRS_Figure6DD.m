
f=figure;                 
               
            
            
        subplot(2,2,1)
        h=plot(0:VAR.irhor-1,VAR.irs_cpi(:,4,shock), 'r', 0:VAR.irhor-1,VAR.irs_cpi(:,5,shock), 'b--');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4(:,4)',VARci.irsL4(:,4)',[0 0 1],[0 0 0],1,0.1)
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4(:,5)',VARci.irsL4(:,5)',[0 0 1],[0 0 0],1,0.25)
        set(h(1),'linewidth',1.5);
        set(h(2),'linewidth',1.5);
        ylim([-0.4 0.2]);
        ti = title('CPI vs. CPI Net of Shelter');
        legend('CPI','CPI net of shelter', 'location','southeast')
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
            hline(0,'k-')
            %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            %xl=xlabel(xlab_text);
            %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
            %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
         subplot(2,2,2)   
        h=plot(0:VAR.irhor-1,VARci.irsDIFF, 'r');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsHDIFF',VARci.irsLDIFF',[0 0 1],[0 0 0],1,0.15)
        set(h(1),'linewidth',1.5);
        ylim([-0.1 0.2]);
        ti = title('Difference: CPI vs. CPI Net of Shelter');
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
        hline(0,'k-')
        %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
        %xl=xlabel(xlab_text);
        %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
        %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
             subplot(2,2,3)
        h=plot(0:VAR.irhor-1,VAR.irs_pce(:,4,shock), 'r', 0:VAR.irhor-1,VAR.irs_pce(:,5,shock), 'b--');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4_pce(:,4)',VARci.irsL4_pce(:,4)',[0 0 1],[0 0 0],1,0.1)
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsH4_pce(:,5)',VARci.irsL4_pce(:,5)',[0 0 1],[0 0 0],1,0.25)
        set(h(1),'linewidth',1.5);
        set(h(2),'linewidth',1.5);
        ylim([-0.4 0.2]);
        ti = title('PCE vs. PCE Net of Shelter');
        legend('PCE','PCE net of shelter', 'location','southeast')
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
            hline(0,'k-')
            %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            %xl=xlabel(xlab_text);
            %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
            %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
         subplot(2,2,4)   
        h=plot(0:VAR.irhor-1,VARci.irsDIFF_pce, 'r');
        [ph,msg]=jbfill(0:VAR.irhor-1,VARci.irsHDIFF_pce',VARci.irsLDIFF_pce',[0 0 1],[0 0 0],1,0.15)
        set(h(1),'linewidth',1.5);
        ylim([-0.1 0.2]);
        ti = title('Difference: PCE vs. PCE Net of Shelter');
        ax = gca;
        ax.XGrid = 'off';
        ax.YGrid = 'on';
        xlim([0 VAR.irhor-1])
        hline(0,'k-')
        %ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
        %xl=xlabel(xlab_text);
        %if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
        %yl=ylabel('percent');
            %elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
            %    yl=ylabel('percentage points');
            %end
            set(gca,'XTick',0:6:VAR.irhor)
           

        
            %set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',12);
            grid on
            ax = gca;
            ax.XGrid = 'off';
            ax.YGrid = 'on';
            
            %str=strcat('figures/',name,'_',plotdisplay{nvar});
            %saveas(gcf,str,'epsc');



%matlab2tikz('irfs_test_figure2.tikz');

            
            